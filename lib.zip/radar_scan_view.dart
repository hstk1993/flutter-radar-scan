import 'dart:math';
import 'package:flutter/material.dart';
import 'radar_scan_config.dart';
import 'radar_scan_painter.dart';

class RadarScanView extends StatefulWidget {
  RadarScanConfig? config;
  Widget? midWidget;

  ///设置midWidget后无效
  VoidCallback? onPressed;

  RadarScanView({Key? key, this.config, this.midWidget, this.onPressed})
      : super(key: key);

  @override
  State<RadarScanView> createState() => _RadarScanViewState();
}

class _RadarScanViewState extends State<RadarScanView>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _imgController;
  late Animation _animation;
  late Animation<double> _imgAnimation;
  late RadarScanConfig _radarScanConfig;
  List imgPoints = [];
  bool flag = false;
  double imgSize = 50;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (widget.config == null) {
      _radarScanConfig = RadarScanConfig();
    } else {
      _radarScanConfig = widget.config!;
    }
    _controller =
        AnimationController(vsync: this, duration: _radarScanConfig.duration);

    _animation = Tween(begin: .0, end: pi * 2).animate(_controller);
    // 图片动画
    _imgController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    final Animation<double> imgCurved =
        CurvedAnimation(parent: _imgController, curve: Curves.easeInOut);
    _imgAnimation = Tween(begin: 0.8, end: 1.0).animate(_imgController);

    _imgController.repeat(reverse: true);
    _controller.repeat();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _imgController.dispose();
    _controller.dispose();
    super.dispose();
  }

  handleCallback(imgPoint) {
    if (flag) return;
    if (imgPoint.isNotEmpty) {
      imgPoints = imgPoint;
      flag = true;
      print("---------");
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    buildImage() {
      return GestureDetector(
        onTap: widget.onPressed,
        child: Container(
          width: imgSize,
          height: imgSize,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
              color: const Color(0xFF3585FE),
              borderRadius: BorderRadius.circular(30)),
          child: Image.asset("assets/icon.png"),
        ),
      );
    }

    Widget buildMidWidget() {
      // if (widget.midWidget != null) {
      //   return widget.midWidget;
      // }
      return Center(
        child: buildImage(),
      );
    }

    _buildImg() {
      List widgets = [];
      for (var element in imgPoints) {
        final lx = size.width / 2 - cos(pi - 45) * size.width / 2;
        final ly = size.height / 2 + sin(pi - 45) * size.width / 2;
        widgets.add(Positioned(
            top: lx,
            left: ly,
            child: ScaleTransition(
              scale: _imgAnimation,
              child: buildImage(),
            )));
      }
      return widgets;
    }

    return Stack(
      fit: StackFit.expand,
      alignment: Alignment.center,
      children: [
        AnimatedBuilder(
            animation: _animation,
            builder: (ctx, child) {
              return CustomPaint(
                painter: RadarScanPainter(_animation.value, handleCallback,
                    sectorAngle: _radarScanConfig.sectorAngle,
                    showMiddleline: _radarScanConfig.showMiddleline,
                    circleCount: _radarScanConfig.circleCount,
                    circleWidth: _radarScanConfig.circleWidth,
                    scanLineWidth: _radarScanConfig.scanLineWidth,
                    scnaLineColor: _radarScanConfig.scnaLineColor,
                    bgLineWidth: _radarScanConfig.bgLineWidth,
                    bgLineColor: _radarScanConfig.bgLineColor,
                    shaderColors: _radarScanConfig.shaderColors),
              );
            }),
        buildMidWidget(),
        ..._buildImg(),
      ],
    );
  }
}
